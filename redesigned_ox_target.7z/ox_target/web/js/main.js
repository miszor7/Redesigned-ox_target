import { createOptions } from "./createOptions.js";

const optionsWrapper = document.getElementById("options-wrapper");
const body = document.body;
const eye = document.getElementById("eye");
const eyeicon = document.getElementById("eyeicon");

const SetStyle = (data) => {
  document.querySelector(':root').style.setProperty('--primary', data.Style.primary);
  document.querySelector(':root').style.setProperty('--secondary', data.Style.secondary);
  document.querySelector(':root').style.setProperty('--background', data.Style.background);
  document.querySelector(':root').style.setProperty('--borderSecondary', data.Style.borderSecondary);
  document.querySelector(':root').style.setProperty('--borderPrimary', data.Style.borderPrimary);
};

window.addEventListener("message", (event) => {
  optionsWrapper.innerHTML = "";

  switch (event.data.event) {
    case "visible": {
      if (event.data.state) {
        eye.classList.remove("active");
      }
      eyeicon.style.visibility = "hidden";
      body.style.visibility = event.data.state ? "visible" : "hidden";
      return;
    }

    case "leftTarget": {
      eyeicon.style.visibility = "hidden";
      eye.classList.remove("active");
      return;
    }

    case "setTarget": {
      eye.style.fill = '#B98AFF';
      eye.classList.add("active");
      eyeicon.style.visibility = "visible";
      if (event.data.options) {
        for (const type in event.data.options) {
          event.data.options[type].forEach((data, id) => {
            let index = 0;
            if(!data.hide) index++;
            createOptions(type, data, id + 1, index);
          });
        }
      }
      if (event.data.zones) {
        for (let i = 0; i < event.data.zones.length; i++) {
          event.data.zones[i].forEach((data, id) => {
            createOptions("zones", data, id + 1, i + 1);
          });
        }
      }
    }
  }
});